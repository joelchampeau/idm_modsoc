Pharo 4.0

This distribution was built October 18, 2015.